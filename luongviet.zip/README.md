# 🇻🇳 Tra Cứu Lương VN

Trang web tra cứu và tính toán lương, thu nhập cho cán bộ, công chức, viên chức và người lao động Việt Nam.

## Tính năng

- ✅ Tính lương **Cán bộ, Công chức, Viên chức** (CCVC) – bao gồm hệ số lương, phụ cấp chức vụ, phụ cấp thâm niên, phụ cấp khu vực, phụ cấp ưu đãi nghề
- ✅ Tính lương **Người Lao Động / HĐLĐ** – ngày công, lương làm thêm giờ, phụ cấp, thuế TNCN
- ✅ Tính **Lương Hưu** – tỷ lệ hưởng, mức bình quân, điều chỉnh 8% từ 01/07/2026
- ✅ **Bảng lương tham chiếu** đầy đủ theo ngạch bậc
- ✅ Danh sách **văn bản pháp luật** còn hiệu lực kèm liên kết chính thức

## Căn cứ pháp lý

| Văn bản | Nội dung |
|---------|----------|
| NĐ 161/2026/NĐ-CP | Lương cơ sở 2.530.000 đ (từ 01/07/2026) |
| NĐ 204/2004/NĐ-CP | Bảng hệ số lương CCVC |
| Luật BHXH 2024 | Công thức tính lương hưu |
| NĐ 74/2024/NĐ-CP | Lương tối thiểu vùng |
| Bộ luật Lao động 2019 | HĐLĐ, làm thêm giờ |

## Cách đưa lên Vercel (dễ lắm!)

### Cách 1 – Kéo thả (Không cần cài gì)
1. Vào **https://vercel.com** → Đăng nhập (có thể dùng Google)
2. Nhấn **"Add New Project"** → Chọn **"Deploy from file upload"**
3. Kéo thả **toàn bộ thư mục** `luong-viet` vào
4. Nhấn **Deploy** → Có link ngay!

### Cách 2 – Dùng GitHub (miễn phí, tự động cập nhật)
1. Tạo tài khoản GitHub → Tạo repository mới (public)
2. Upload file `index.html` và `vercel.json` lên GitHub
3. Vào vercel.com → **"Import Git Repository"** → chọn repo vừa tạo
4. Nhấn **Deploy** → Xong!

### Cách 3 – Dùng lệnh (nếu có Node.js)
```bash
npm install -g vercel
cd luong-viet
vercel --prod
```

## Tùy chỉnh

Toàn bộ logic tính toán nằm trong thẻ `<script>` ở cuối file `index.html`.
Có thể chỉnh sửa bằng bất kỳ phần mềm soạn thảo văn bản nào (Notepad, VS Code...).

---
*Kết quả mang tính tham khảo. Để biết chính xác, liên hệ phòng tổ chức hoặc BHXH địa phương.*
